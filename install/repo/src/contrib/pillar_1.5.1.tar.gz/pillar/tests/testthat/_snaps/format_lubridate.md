# can output durations

    Code
      pillar(v)
    Output
      <pillar>
      <Duration>
      1s        
      2s        
      3s        

