# output test

    Code
      pillar(add_special(as.Date("2017-07-28")))
    Output
      <pillar>
      <date>    
      2017-07-28
      NA        

