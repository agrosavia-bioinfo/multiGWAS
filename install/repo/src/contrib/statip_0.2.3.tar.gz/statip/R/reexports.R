
# #' @importFrom bazar is_empty
# #' @export
# #' 
# bazar::is_empty
