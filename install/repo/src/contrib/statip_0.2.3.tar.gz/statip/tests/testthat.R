
library(testthat)
test_check("statip")
