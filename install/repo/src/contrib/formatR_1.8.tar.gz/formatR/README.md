# formatR

[![R-CMD-check](https://github.com/yihui/formatR/actions/workflows/R-CMD-check.yaml/badge.svg)](https://github.com/yihui/formatR/actions/workflows/R-CMD-check.yaml)
[![CRAN release](https://www.r-pkg.org/badges/version/formatR)](https://cran.r-project.org/package=formatR)

Format R code automatically.

See the package homepage <https://yihui.org/formatR> for more information.
