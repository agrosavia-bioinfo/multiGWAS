
#' Frequently Asked Questions
#'
#' @name faq
#' @includeRmd man/chunks/FAQ.Rmd
NULL
