# ansi_columns

    foo 1     foo 2     foo 3     foo 4     
    foo 5     foo 6     foo 7     foo 8     
    foo 9     foo 10                        

---

    123456789012...

