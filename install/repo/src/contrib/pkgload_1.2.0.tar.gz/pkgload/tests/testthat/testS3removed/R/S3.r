
#' @export
as.character.pkgload_foobar <- function(x, ...) {
  "registered"
}
