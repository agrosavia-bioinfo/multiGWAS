
# #' @export
.methodsList <- 
function()
{
  c("asselin",
    #"chernoff",
    "density",
    "discrete",
    #"devroye",
    #"ekblom",
    #"eme",
    "grenander",
    "hrm",
    "hsm",
    "kernel",
    #"kim",
    "lientz",
    #"lms",
    #"logspline", # cf. package logspline
    "meanshift", 
    "mfv",# most frequent value
    #"mizoguchi",
    "naive",
    "parzen",
    #"robertson",
    "shorth",
    #"splines",                 
    "tsybakov",
    "venter", 
    "vieu")
#"wavelet",
#"wtp")
}
