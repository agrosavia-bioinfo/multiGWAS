library(testthat)
library(ldsep)

test_check("ldsep")
