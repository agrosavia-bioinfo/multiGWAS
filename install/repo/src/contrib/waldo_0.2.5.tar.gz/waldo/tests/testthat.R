library(testthat)
library(waldo)

test_check("waldo")
