# src_sqlite() gives meaningful error messages

    Code
      src_sqlite(":memory:")
    Error <rlang_error>
      `path` must already exist, unless `create` = TRUE.

