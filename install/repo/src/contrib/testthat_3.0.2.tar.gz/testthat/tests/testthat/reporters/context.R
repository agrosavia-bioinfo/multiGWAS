testthat:::local_edition(2)
context("my context")

test_that("a test", {
  expect_true(TRUE)
})
