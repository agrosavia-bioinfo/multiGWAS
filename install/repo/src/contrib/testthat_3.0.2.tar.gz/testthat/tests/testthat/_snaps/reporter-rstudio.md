# reporter basics works

    tests.R:12:3 [failure] Failure:1. FALSE is not TRUE
    tests.R:17:3 [failure] Failure:2a. FALSE is not TRUE
    tests.R:23:3 [error] Error:1. stop
    tests.R:31:3 [error] errors get tracebacks. !
    tests.R:37:3 [skip] explicit skips are reported. Reason: skip
    tests.R:40:1 [skip] empty tests are implicitly skipped. Reason: empty test
    tests.R:49:3 [warning] warnings get backtraces. def

